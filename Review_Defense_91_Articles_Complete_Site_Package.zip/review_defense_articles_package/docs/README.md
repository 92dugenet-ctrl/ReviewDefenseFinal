# Review Defense — Package éditorial 91 articles

Ce package regroupe le contenu éditorial complet et les illustrations des 91 articles.

## Structure
- `articles/markdown/` : source des 91 articles, sans modification rédactionnelle.
- `articles/html/` : version HTML autonome de chaque article, sans header/footer global.
- `illustrations/` : 91 SVG associés article par article, format 1140×760 (3:2).
- `data/articles.json` : registre global : ID, catégorie, titre, slug, SEO, route, fichier HTML, Markdown et SVG.
- `index.html` : index des 91 articles.
- `sitemap.xml` : sitemap avec domaine placeholder à remplacer par le domaine réel.

## Intégration
Le site peut injecter son header et son footer global autour du contenu de chaque HTML. Les fichiers d'article n'embarquent volontairement ni navigation globale, ni footer global, ni auteur/date/share.

## Image
Chaque article pointe vers son SVG correspondant. Les SVG utilisent `viewBox="0 0 1140 760"` et un ratio 3:2.

## SEO
Les titres, descriptions, slugs, mots-clés et intentions proviennent des données éditoriales présentes dans les sources des 91 articles. Le domaine du sitemap est volontairement laissé en placeholder.
